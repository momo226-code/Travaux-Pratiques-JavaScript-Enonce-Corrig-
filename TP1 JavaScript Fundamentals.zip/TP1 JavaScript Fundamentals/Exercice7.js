const pascalTriangle = (n) => {
    let triangle = []

    for (let i = 0; i < n; i++) {
        triangle[i] = []

        for (let j = 0; j <= i; j++) {
            if (j === 0 || j === i) {
                triangle[i][j] = 1
            } else {
                triangle[i][j] =
                    triangle[i - 1][j - 1] + triangle[i - 1][j]
            }
        }
    }

    return triangle
}


///////////////////////////////////////////////////////////////////////
const binomial = (n, k) => {
    if (k < 0 || k > n) return 0
    if (k === 0 || k === n) return 1

    return binomial(n - 1, k - 1) + binomial(n - 1, k)
}



///////////////////////////////////////////////////////////////////
const printPascal = (n) => {
    const triangle = pascalTriangle(n)

    const maxWidth = triangle[n - 1].join("   ").length

    for (let row of triangle) {
        let line = row.join("   ")
        let spaces = Math.floor((maxWidth - line.length) / 2)
        console.log(" ".repeat(spaces) + line)
    }
}


printPascal(6)