const caesarEncrypt = ( text, shift) =>{




    let code2 = text.replace(/[a-zA-a]/g , c=> {
                                                let type = (c >= "a")? 97:65 ;
                                                return String.fromCharCode( ((c.charCodeAt(0)-type+shift)%26 + type))}
                                            )

    return code2 ;

    /*let code = ""

    for ( let c of text){

        if ( c >= "a" && c<="z"){
            code += String.fromCharCode(  ((c.charCodeAt(0)-97+shift)%26 + 97) )
        }else if (c >= "A" && c <= "Z") {
            code += String.fromCharCode(
                ((c.charCodeAt(0) - 65 + shift) % 26) + 65
            )
        } else {
            code += c  
        }

    }*/


 


}


console.log(caesarEncrypt ("Hello , World !", 3))


const caesarDecrypt = (text, shift) =>{

    let decrypt = text.replace(/[a-zA-Z]/g,c=> {
                                                let type = (c >= "a")? 97:65 ;
                                                return String.fromCharCode( ((c.charCodeAt(0)-type-shift+26)%26 + type))})


    return decrypt ;



} ;

console.log( caesarDecrypt("Khoor , Zruog !" , 3))



const caesarCrack = (ciphertext) =>{

        for (let shift = 0; shift < 26; shift++) {
        let decrypted = ciphertext.replace(/[a-zA-Z]/g, c => {
            let type = c >= "a" ? 97 : 65
            return String.fromCharCode(
                ((c.charCodeAt(0) - type - shift + 26) % 26) + type
            )
        })

        console.log(`shift ${shift} → ${decrypted}`)
    }
    }


caesarCrack("Hello, World") ;