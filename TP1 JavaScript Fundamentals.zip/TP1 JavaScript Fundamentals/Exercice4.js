const gcd =  ( a ,b ) => {

    a = Math.abs( a) ;
    b = Math.abs ( b) ;

    while ( b !== 0) {
        let temp = b ;
        b = a%b ;
        a = temp ;
    }

    return a;
}


console.log( gcd ( -5 ,1))


const gcdRecursive = (a, b) => {
    a = Math.abs( a) ;
    b = Math.abs( b) ;
    if (b===0) return a ;
    return gcdRecursive ( b , a%b) ;
}

console.log( gcdRecursive(-5 , 0)) ;


const  lcm = (a, b) => {

    if ( b === 0 || a===0) return 0 ;
    return (Math.abs( a * b ))/gcd(a,b) ;

}

console.log( lcm(12,18)) ;


