const collatzSequence =(n)=>{

        n = Math.abs(n)

        let sequ= [] ;

        sequ.push(n) ;

        while ( sequ.at(-1) != 1) {
            let last = sequ.at(-1)
            sequ.push(( last % 2 == 0) ? last/2 : 3*last+1) ;
        }
       
        return sequ ;


};

console.log( collatzSequence(6))
/// [6 , 3, 10 , 5, 16 , 8, 4, 2, 1]


const collatzLength = (n)=>{

         n = Math.abs(n)

        let count = 0 ;
         while ( n != 1) {
            n = ( n% 2 == 0) ? n/2 : 3*n+1
            count ++ ;
        }
       
      return count ;



} 

console.log(collatzLength(27)) ;


const longestCollatz = (max) => {
    let maxL = 0
    let maxNumber = 1

    for (let i = 1; i <= max; i++) {
        let len = collatzLength(i)

        if (len > maxL) {
            maxL = len
            maxNumber = i
        }
    }

    return `Number : ${maxNumber} , ${maxL} Steps !!`
}


console.log( longestCollatz(100))