// Les méthodes itératives 
const fibonnaci = ( n ) => {
        if ( n === 0) return 0 ;
        let a = 0 ;
        let b = 1 ;
     
        for (let i = 2 ; i <= n ; i++ ){
            let c =  a+b ;
            a = b ;
            b = c ; 
        }
        return b ;
} 

console.log ( fibonnaci ( 10 ) , fibonnaci ( 4)) ; 

const fibonnacciSequence = (n) => {

    if ( n <= 0) return [] ;
    if ( n === 1 ) return [0] ;

    let arr = [0 , 1] ;
    for ( let i = 2 ; i < n ; i++) {
        arr.push( arr [i-1] + arr[i-2]) ;
    }

    return arr ;

}


console.log( fibonnacciSequence(7)) ;


// Les méthodes recursives 


const recursiveFibonnaci = ( n ) => {

    return ( n == 0 )  ?  0 : 
            (n == 1 ) ? 1 :
            recursiveFibonnaci ( n -1) + recursiveFibonnaci ( n-2) ;

}

console.log( recursiveFibonnaci( 10 ) , recursiveFibonnaci(4)) ;

const recursiveFibonnaciSequence = ( n ) => {
    
        if ( n == 0) return [] ;
        if ( n == 1) return [0] ;
        if ( n == 2 ) return  [ 0 , 1 ] ;

        let avant = recursiveFibonnaciSequence(n-1) ;
        let prochain = avant[avant.length -1] + avant[ avant.length-2] ;
        avant.push( prochain) ;
        return avant ;            

}

console.log( recursiveFibonnaciSequence(7)) ; 


const n = 35;
console.time("recursive");
recursiveFibonnaci(n); // calcul récursif  recursive: 105.598876953125 ms
console.timeEnd("recursive");


console.time("iterative");
fibonnaci(n); // calcul itératif // 0.005126953125 ms
console.timeEnd("iterative");


const n1 = 35;

console.time("recursive");
recursiveFibonnaciSequence(n1); //0.016845703125 ms
console.timeEnd("recursive");

console.time("iterative");  //0.010986328125 ms
console.timeEnd("iterative");



/*
    Les méthodes itératives sont plus rapides alors que celles
    recursives necessitent beaucoup de coup d'appels 
    de la fonction et donc de gestion de la stack etc.
*/