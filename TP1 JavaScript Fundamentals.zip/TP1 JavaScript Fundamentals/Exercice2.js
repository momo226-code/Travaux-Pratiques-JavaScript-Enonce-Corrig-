const isPalindrome = ( str ) => {

    str = str.toLowerCase().replace(/\s/g, "")

    let str_bac = str.split("").reverse().join("")

    return str_bac === str ? true : false 
    
}


const isPalindromeNumber = (n) => {
    let original = n
    let reversed = 0;

    while (n > 0) {
        reversed = reversed * 10 + n % 10;
        n = Math.floor(n / 10);         
    }

    return reversed == original ;
};



console.log(isPalindromeNumber ( 121 ) )
console.log( isPalindromeNumber ( 1331) )
console.log ( isPalindromeNumber ( 51) )