    const isPrime = ( n ) => {
        if ( n < 0 ) n = -n ;

        if ( n === 0 || n === 1){
        return false 
        }

        if ( n === 2) {
            return true 
        }
    
        for ( let i = 2 ; i <= Math.sqrt(n) ; i++){
            return  n % i === 0 ? false : true
        }

    }
    console.log(isPrime (2)) 
    console.log(isPrime (17))
    console.log(isPrime (4) )
    console.log(isPrime (1)) 
    console.log(isPrime ( -5)) 


    const listPrimes = ( min , max) => {

        for ( let i = min ; i <= max ; i++ ) {
            if (isPrime(i)) console.log(i)
    }

    }

    listPrimes ( 5 , 1000)

