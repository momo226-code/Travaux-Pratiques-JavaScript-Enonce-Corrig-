const mean = (arr) => {
    return arr.reduce((sum, x) => sum + x, 0) / arr.length
}
;
const median = (arr) => {
    let sorted = [...arr].sort((a, b) => a - b)
    let n = sorted.length
    let mid = Math.floor(n / 2)

    if (n % 2 === 0) {
        return (sorted[mid - 1] + sorted[mid]) / 2
    } else {
        return sorted[mid]
    }
}


const mode = (arr) => {
    let freq = {}
    let maxFreq = 0

    for (let x of arr) {
        freq[x] = (freq[x] || 0) + 1
        if (freq[x] > maxFreq) {
            maxFreq = freq[x]
        }
    }

    let modes = []
    for (let key in freq) {
        if (freq[key] === maxFreq) {
            modes.push(Number(key))
        }
    }

    return modes
}



const stdDev = (arr) => {
    let avg = mean(arr)
    let sum = 0

    for (let x of arr) {
        sum += (x - avg) ** 2
    }

    return Math.sqrt(sum / arr.length)
}


const stats = (arr) => {
    return {
        mean: mean(arr),
        median: median(arr),
        mode: mode(arr),
        stdDev: stdDev(arr)
    }
}



const data = [4, 8, 6, 5, 3, 7, 8, 9]

console.log(mean(data))    
console.log(median(data))  
console.log(mode(data))    
console.log(stdDev(data))  
console.log(stats(data))
