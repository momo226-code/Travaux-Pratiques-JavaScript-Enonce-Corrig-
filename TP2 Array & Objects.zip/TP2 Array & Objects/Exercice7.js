const deepCopy = ( obj) => {


    if( typeof obj !== "object" || obj === null){
        return obj ;
    }
    if( Array.isArray(obj)){
        return obj.map( items => deepCopy(items))
    }

    const copy = {} ;
    for( let key in obj){
        copy[key] = deepCopy(obj[key]) ;
    }

    return copy ;

}

const string = "helo,hi.helllo"
console.log(string.split(",", "."))

const deepGet = (obj, path)=>{
    
    
    const value = path.split(".").reduce((acc , key)=> { 
        return acc?.[key]} , 
        obj)


    return value 


}



const deepSet = (obj , path , value) => {

    const keys = path.split(".") ;
    


}



const obj = {
  user: {
    name: "Sara",
    address: { city: "Rabat" }
  }
};

console.log(deepSet(obj, "user.address.zip", 10000));


console.log(deepGet (obj , "user.address.city"))
// " Rabat "
console.log(deepGet (obj , "user.phone"))
// undefined
console.log(deepSet (obj , " user.address.zip", 10000))
//obj . user . address . zip === 10000
console.log(deepSet ({} , "a.b.c", 42))
//{ a: { b: { c: 42 } } }  