const isEqual = (a, b) => {
  
  if (a === b) return true;

  if (
    typeof a !== "object" || a === null ||
    typeof b !== "object" || b === null
  ) return false;


  const keysA = Object.keys(a);
  const keysB = Object.keys(b);

  if (keysA.length !== keysB.length) return false;


  return keysA.every(key => isEqual(a[key], b[key]));
};


const diff = (obj1, obj2) => {
 
  const allKeys = new Set([
    ...Object.keys(obj1),
    ...Object.keys(obj2)
  ]);

  
  return Object.fromEntries(
    [...allKeys]

      .filter(key => !isEqual(obj1[key], obj2[key]))

    
      .map(key => [
        key,
        {
          ...(key in obj1 && { old: obj1[key] }), // ancienne valeur
          ...(key in obj2 && { new: obj2[key] })  // nouvelle valeur
        }
      ])
  );
};



const isObject = val =>
  typeof val === "object" && val !== null && !Array.isArray(val);

const merge = (target, ...sources) => {

  for (const source of sources) {

   
    Object.entries(source).forEach(([key, value]) => {

     
      if (isObject(value)) {
        target[key] = merge(target[key] || {}, value);
      } 
     
      else {
        target[key] = value;
      }

    });
  }

  return target;
};



console.log(isEqual ({a: 1} , {a: 1})) // true
console.log(isEqual ({a: {b: 2}} , {a: {b: 2}})) // true
console.log(isEqual ({a: 1} , {a: 2})) // false
console.log(diff (
{ a: 1 , b: 2, c: 3 } ,
{ a: 1 , b: 5, d: 4 }
))
// { b: {old :2 , new :5} , c:{ old :3} ,
// d:{ new :4} }

console.log ( merge ({ a: 1, b: { x: 1 } },
{ b: { y: 2 } , c: 3 })
// { a: 1, b: { x: 1, y: 2 }, c: 3 }
)