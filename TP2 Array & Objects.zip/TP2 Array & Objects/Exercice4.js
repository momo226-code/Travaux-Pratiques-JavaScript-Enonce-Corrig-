

const rotateLeft = (array, k) => {

    const left = array.slice (0 ,k) ;

    const right = array.slice ( k , array.length) ;

    return [... right , ... left]
 
}

console.log ( rotateLeft ([1 ,2 ,3 ,4 ,5] , 2))
//[3 ,4 ,5 ,1 ,2]


const rotateRight = ( array , k) =>{


    const right = array.slice (0 ,k+1) ;
    console.log( right) ;

    const left = array.slice ( k+1, array.length) ;
    console.log ( left) ;

    return [... left, ... right]

}


console.log( rotateRight ([1 ,2 ,3 ,4 ,5] , 2)
// [4 ,5 ,1 ,2 ,3]
)