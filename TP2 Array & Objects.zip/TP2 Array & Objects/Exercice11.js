const mutualFriends = (users, id1, id2) => {
  const user1 = users.find(u => u.id === id1);
  const user2 = users.find(u => u.id === id2);

  const result = [];

  for (let friendId of user1.friends) {
    if (user2.friends.includes(friendId)) {
      const friend = users.find(u => u.id === friendId);
      result.push(friend.name);
    }
  }

  return result;
};


const suggestFriends = (users, userId) => {
  const user = users.find(u => u.id === userId);
  const suggestions = [];

  for (let friendId of user.friends) {
    const friend = users.find(u => u.id === friendId);

    for (let friendOfFriend of friend.friends) {
      if (
        friendOfFriend !== userId &&
        !user.friends.includes(friendOfFriend)
      ) {
        if (!suggestions.includes(friendOfFriend)) {
          suggestions.push(friendOfFriend);
        }
      }
    }
  }

  return suggestions.map(id => 
    users.find(u => u.id === id).name
  );
};



const mostPopular = (users) => {
  let maxUser = null;
  let maxCount = 0;

  for (let user of users) {
    if (user.friends.length > maxCount) {
      maxCount = user.friends.length;
      maxUser = user;
    }
  }

  return {
    id: maxUser.id,
    name: maxUser.name,
    count: maxCount
  };
};


const connectionDegree = (users, id1, id2) => {
  if (id1 === id2) return 0;

  const visited = new Set();
  const queue = [[id1, 0]];

  while (queue.length > 0) {
    const [currentId, degree] = queue.shift();

    if (currentId === id2) {
      return degree;
    }

    visited.add(currentId);

    const user = users.find(u => u.id === currentId);

    for (let friendId of user.friends) {
      if (!visited.has(friendId)) {
        queue.push([friendId, degree + 1]);
      }
    }
  }

  return -1; // pas connecté
};


const users = [
{id :1 , name :" Amina ", friends :[2 ,3 ,4]} ,
{id :2 , name :" Mohammed ", friends :[1 ,3 ,5]} ,
{id :3 , name :" Youssef ", friends :[1 ,2 ,4 ,5]} ,
{id :4 , name :" Sara ", friends :[1 ,3]} ,
{id :5 , name :" Rita ", friends :[2 ,3]}
];


console.log(mutualFriends (users , 1, 2))
// [" Youssef "]
console.log(suggestFriends (users , 1))
// [" Rita "] ( friend of Mohammed / Youssef )
console.log(mostPopular ( users ))
// {id :3 , name :" Youssef ", count :4}
