const getTotalValue = (inventory) => {
  let total = 0;

  for (let product of inventory) {
    total += product.price * product.quantity;
  }

  return total;
};

const getLowStock = (inventory, threshold) => {
  return inventory.filter(product => 
    product.quantity <= threshold
  );
};


const getByCategory = (inventory) => {
  const result = {};

  for (let product of inventory) {
    const category = product.category;

    if (!result[category]) {
      result[category] = [];
    }

    result[category].push(product);
  }

  return result;
};



const applyDiscount = (inventory, category, percent) => {
  for (let product of inventory) {
    if (product.category === category) {
      product.price = product.price - (product.price * percent / 100);
    }
  }

  return inventory;
};


const inventory = [
{id :1 , name :" Laptop ", category :" Electronics ",
price :9990 , quantity :5} ,
{id :2 , name :" Mouse ", category :" Electronics ",
price :290 , quantity :50} ,
{id :3 , name :" Desk ", category :" Furniture ",
price :1990 , quantity :10} ,
{id :4 , name :" Chair ", category :" Furniture ",
price :1490 , quantity :3} ,
{id :5 , name :" Notebook ", category :" Stationery ",
price :50 , quantity :100}]



console.log(getTotalValue ( inventory ))
// 91740
console.log(getLowStock ( inventory , 5))
// [{ id :4 , name :" Chair " ,...}]
console.log(getByCategory ( inventory ))
// { Electronics : [...] ,
// Furniture : [...] ,
// Stationery : [...] }


/*console.log(getTotalValue(inventory));
console.log(getLowStock(inventory, 5));
console.log(getByCategory(inventory));
console.log(applyDiscount(inventory, "Electronics", 10));*/
