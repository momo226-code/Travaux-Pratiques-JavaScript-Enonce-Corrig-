const chunk = (array, size) => {

    let r = [] ;

    for ( let i = 0 ; i < array.length ; i+=size){
            r.push (array.slice( i , size+i) ) ;  
    }
    return r ;
} 
console.log(chunk([1,2,3,4,5] , 2)) ; 

console.log (chunk ([ 'a', 'b' , 'c' , 'd' ], 3) )


const flatten = (array, depth = 1) => {
    if (depth === 0) return array

    let result = []

    for (let item of array) {
        if (Array.isArray(item)) {
            result.push(...flatten(item, depth - 1))
        } else {
            result.push(item)
        }
    }

    return result
}

console.log(flatten([1, [2, [3, [4]]]], 1))
console.log(flatten([1, [2, [3, [4]]]], 2))
console.log(flatten([1, [2, [3, [4]]]], 3))

