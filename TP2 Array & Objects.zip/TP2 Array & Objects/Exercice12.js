const calculateGPA = (student) => {
  const gradePoints = {
    A: 4,
    B: 3,
    C: 2,
    D: 1,
    F: 0
  };

  let totalPoints = 0;
  let totalCredits = 0;

  for (let course of student.courses) {
    totalPoints += gradePoints[course.grade] * course.credits;
    totalCredits += course.credits;
  }

  return totalPoints / totalCredits;
};






const rankStudents = (students) => {
  const copy = [...students];

  copy.sort((a, b) => 
    calculateGPA(b) - calculateGPA(a)
  );

  for (let i = 0; i < copy.length; i++) {
    copy[i].rank = i + 1;
  }

  return copy;
};


const courseStatistics = (students, courseName) => {
  const grades = [];

  for (let student of students) {
    const course = student.courses.find(c => c.name === courseName);
    if (course) {
      grades.push(course.grade);
    }
  }

  const gradePoints = { A:4, B:3, C:2, D:1, F:0 };

  const values = grades.map(g => gradePoints[g]);

  values.sort((a, b) => a - b);

  const min = values[0];
  const max = values[values.length - 1];

  const avg = values.reduce((sum, v) => sum + v, 0) / values.length;

  let median;
  const mid = Math.floor(values.length / 2);

  if (values.length % 2 === 0) {
    median = (values[mid - 1] + values[mid]) / 2;
  } else {
    median = values[mid];
  }

  return { min, max, avg, median };
};



const honorRoll = (students, minGPA) => {
  const result = [];

  for (let student of students) {
    if (calculateGPA(student) >= minGPA) {
      result.push(student);
    }
  }

  return result;
};



const students = [
{id: 1 , name : " Sara ", courses : [
{ name : " Math ", grade : "A", credits : 4} ,
{ name : " Physics ", grade : "B", credits : 3} ,
{ name : "CS", grade : "A", credits : 3}]} ,
{id: 2 , name : " Youssef ", courses : [
{ name : " Math ", grade : "B", credits : 4} ,
{ name : " Physics ", grade : "A", credits : 3} ,
{ name : "CS", grade : "B", credits : 3}
]} // ... more students
];


console.log("=== GPA ===");
console.log("Sara:", calculateGPA(students[0]));      // attendu ~ 3.7
console.log("Youssef:", calculateGPA(students[1]));   // attendu ~ 3.3

console.log("\n=== Ranking ===");
console.log(rankStudents(students));

console.log("\n=== Course Statistics (Math) ===");
console.log(courseStatistics(students, "Math"));

console.log("\n=== Honor Roll (min 3.5) ===");
console.log(honorRoll(students, 3.5));
