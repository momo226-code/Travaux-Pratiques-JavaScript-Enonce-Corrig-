const pick = (obj, keys) => {


  keys = keys.map ( x => x.toLowerCase().trim()) ;

   //const result3 = Object.entries(obj).filter(([keyy])=>keys.includes(keyy.toLowerCase()))

  let resul = Object.entries(obj).reduce( ( acc , [key , value])=>

    {
        if ( keys.includes(key.toLowerCase()))
            acc[key] = value 

        return acc
    } , {}

)
  return resul ;


}

const user = { name :" Sara ", age :25 , city :" Rabat "};

// { name : " Sara ", age : 25 }
console.log( pick (user , [" name ", " age "]) )


const omit = (obj, keys) => {

    keys = keys.map(x => x.trim().toLowerCase()) 
    const r = Object.entries(obj).filter ( ([key , value])=> !keys.includes(key.toLowerCase())) ;

    return Object.fromEntries ( r) ;

} 



console.log ( omit (user , [" age "]) )
// { name : " Sara ", city : " Rabat " })


const invert =  ( obj ) =>{

  let res = Object.entries(obj).reduce ( (acc , [key , value])=>{
            acc[value] =key
            return acc
  } , {})


  return res ;

}

console.log( invert ({ a: 1, b: 2 }) )
// { 1: "a", 2: "b" }



const mapValues = ( Obj , fn) => {

   let re = Object.entries(Obj).reduce( ( acc , [key , value]) =>{

      acc[key] = fn(value)
      return acc
    }, {}) 

 // let er = Object.entries(Obj).map( ( [key , value]) => [key ,fn(value)]) 

  return re

}

console.log(mapValues ({ a: 1 , b: 2 }, x => x * 2)) ;


// { a: 2, b: 4 }