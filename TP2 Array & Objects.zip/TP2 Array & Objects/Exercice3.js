const unique = ( array) => {

    return [... new Set (array) ]
}

console.log ( unique ([1 , 2, 2, 3, 3 , 3, 4])
)







//////////////////////////////////////////////////////
const duplicates  = ( array) =>{


    return unique(array.filter ( a=> frequency ( array )[a] >= 2));
}

console.log ( duplicates ([1 , 2 , 2, 3, 3, 3, 4]) )









////////////////////////////////////
const frequency = (array) => {

    const count = array. reduce (( acc ,fruit ) => {
            acc [ fruit ] = ( acc [ fruit ] || 0) + 1;
            return acc ; } , {}) ;

    return count ; 

}

console.log ( frequency([1 , 2, 2, 3, 3, 3])) ;
console.log ( frequency (['a', 'a' , 'b' , 'a' , 'c']) )



