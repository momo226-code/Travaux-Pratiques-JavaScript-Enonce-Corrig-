const totalSalesByMonth = (sales) => {
  const result = {};

  for (let sale of sales) {
    const month = sale.date.slice(0, 7); // "2024-01"
    const total = sale.qty * sale.price;

    if (!result[month]) {
      result[month] = 0;
    }

    result[month] += total;
  }

  return result;
};



const topSeller = (sales) => {
  const totals = {};

  for (let sale of sales) {
    const total = sale.qty * sale.price;

    if (!totals[sale.product]) {
      totals[sale.product] = 0;
    }

    totals[sale.product] += total;
  }

  let maxProduct = null;
  let maxTotal = 0;

  for (let product in totals) {
    if (totals[product] > maxTotal) {
      maxTotal = totals[product];
      maxProduct = product;
    }
  }

  return { product: maxProduct, total: maxTotal };
};



const averageOrderValue = (sales) => {
  let sum = 0;

  for (let sale of sales) {
    sum += sale.qty * sale.price;
  }

  return sum / sales.length;
};


const salesGrowth = (sales) => {
  const monthly = totalSalesByMonth(sales);
  const months = Object.keys(monthly).sort();

  const firstMonth = monthly[months[0]];
  const lastMonth = monthly[months[months.length - 1]];

  const growth = ((lastMonth - firstMonth) / firstMonth) * 100;

  return growth;
};



const sales = [
{ date :" 2024 -01 -15 ", product :"A", qty :10 , price :100} ,
{ date :" 2024 -01 -20 ", product :"B", qty :5 , price :200} ,
{ date :" 2024 -02 -10 ", product :"A", qty :15 , price :100} ,
{ date :" 2024 -02 -25 ", product :"C", qty :8 , price :150} ,
{ date :" 2024 -03 -05 ", product :"B", qty :12 , price :200} ,
{ date :" 2024 -03 -18 ", product :"A", qty :20 , price :100}
];


console.log(totalSalesByMonth ( sales ))
// {"2024 -01": 2000 ,
// "2024 -02": 2700 ,
// "2024 -03": 4400}
console.log(topSeller ( sales ))
// { product : "A", total : 4500}
console.log(averageOrderValue ( sales ))
// 1516.67

