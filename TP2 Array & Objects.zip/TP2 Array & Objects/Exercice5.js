const sortByLength = (strings) =>{

    return strings.sort ( ( a , b) => a.length - b.length) ;

}

console.log( sortByLength(["aaa", "b", "cc"]));


const sortByProperty = (objects, prop, order = "asc") => {
    return objects.sort((a, b) => {
        if (order === "asc") {
            return a[prop].localeCompare(b[prop])
        } else {
            return b[prop].localeCompare(a[prop])
        }
    })
}

console.log(
    sortByProperty(
        [{ name: "Z", age: 20 }, { name: "A", age: 30 }],
        "name",
        "asc"
    )
)
