const processNumbers = ( numbers) => { 

    numbers = numbers.filter( x => x > 0 ) ;



    numbers = numbers.map ( x => x**2) ;

  
   
    numbers = numbers.filter ( x=> x <=100) ;


    numbers = numbers.sort(( a, b) => a< b) ;


    return numbers.reduce( ( acc , x) => acc+x , 0)


}

console.log( processNumbers ([1 , -2, 3, 4, -5, 6, 11]) 
)
console.log ( processNumbers ([15 , 20]) ) ;